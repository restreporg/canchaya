<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Canchaya - Reserva tu cancha</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        .hero {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
            min-height: 100vh;
        }
        .hero-title { font-size: 3.5rem; font-weight: 800; }
        .card-feature { border: none; border-radius: 16px; transition: transform .2s; }
        .card-feature:hover { transform: translateY(-5px); }
        .icon-circle {
            width: 60px; height: 60px; border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            font-size: 1.5rem;
        }
    </style>
</head>
<body>

    
    <nav class="navbar navbar-expand-lg navbar-dark bg-transparent position-absolute w-100" style="z-index:10">
        <div class="container">
            <a class="navbar-brand fw-bold fs-4" href="/">
                <i class="bi bi-dribbble me-2"></i>Canchaya
            </a>
            <div class="ms-auto d-flex gap-2">
                <?php if(auth()->guard()->check()): ?>
                    <?php if(auth()->user()->role === 'admin'): ?>
                        <a href="<?php echo e(route('admin.courts.index')); ?>" class="btn btn-light btn-sm">
                            <i class="bi bi-grid me-1"></i>Panel Admin
                        </a>
                    <?php else: ?>
                        <a href="<?php echo e(route('client.reservations.index')); ?>" class="btn btn-light btn-sm">
                            <i class="bi bi-calendar-check me-1"></i>Mis Reservas
                        </a>
                    <?php endif; ?>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-light btn-sm">
                        <i class="bi bi-box-arrow-in-right me-1"></i>Iniciar sesión
                    </a>
                    <a href="<?php echo e(route('register')); ?>" class="btn btn-primary btn-sm">
                        <i class="bi bi-person-plus me-1"></i>Registrarse
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    
    <section class="hero d-flex align-items-center text-white">
        <div class="container text-center py-5">
            <p class="text-uppercase text-primary fw-semibold mb-2 letter-spacing">
                <i class="bi bi-geo-alt me-1"></i> La mejor plataforma de reservas
            </p>
            <h1 class="hero-title mb-4">
                Reserva tu cancha <br>
                <span class="text-primary">en segundos</span>
            </h1>
            <p class="lead text-white-50 mb-5 mx-auto" style="max-width: 500px;">
                Encuentra disponibilidad en tiempo real, elige tu horario y paga fácilmente.
            </p>
            <div class="d-flex justify-content-center gap-3">
                <a href="<?php echo e(route('register')); ?>" class="btn btn-primary btn-lg px-5">
                    <i class="bi bi-lightning-charge me-2"></i>Reservar ahora
                </a>
                <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-light btn-lg px-5">
                    <i class="bi bi-box-arrow-in-right me-2"></i>Iniciar sesión
                </a>
            </div>
        </div>
    </section>

    
    <section class="py-6 bg-light" style="padding: 80px 0;">
        <div class="container">
            <h2 class="text-center fw-bold mb-2">¿Por qué Canchaya?</h2>
            <p class="text-center text-muted mb-5">Todo lo que necesitas para reservar en un solo lugar</p>

            <div class="row g-4">
                <div class="col-md-4">
                    <div class="card card-feature p-4 h-100 shadow-sm">
                        <div class="icon-circle bg-primary bg-opacity-10 text-primary mb-3">
                            <i class="bi bi-calendar2-check"></i>
                        </div>
                        <h5 class="fw-bold">Reserva fácil</h5>
                        <p class="text-muted mb-0">Elige cancha, fecha y hora en pocos clics. Sin llamadas ni filas.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card card-feature p-4 h-100 shadow-sm">
                        <div class="icon-circle bg-success bg-opacity-10 text-success mb-3">
                            <i class="bi bi-clock-history"></i>
                        </div>
                        <h5 class="fw-bold">Disponibilidad en tiempo real</h5>
                        <p class="text-muted mb-0">Consulta los horarios disponibles al instante y reserva sin conflictos.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card card-feature p-4 h-100 shadow-sm">
                        <div class="icon-circle bg-warning bg-opacity-10 text-warning mb-3">
                            <i class="bi bi-credit-card"></i>
                        </div>
                        <h5 class="fw-bold">Pago seguro</h5>
                        <p class="text-muted mb-0">Paga con efectivo, tarjeta o transferencia de forma rápida y segura.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    
    <footer class="bg-dark text-white-50 py-4 text-center">
        <div class="container">
            <p class="mb-0">
                <i class="bi bi-dribbble me-2"></i>
                <strong class="text-white">Canchaya</strong> &copy; <?php echo e(date('Y')); ?> — Todos los derechos reservados.
            </p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\wamp64\www\canchaya\canchaya\resources\views/welcome.blade.php ENDPATH**/ ?>