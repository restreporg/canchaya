<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Court;
use Illuminate\Http\Request;

class CourtController extends Controller
{
    public function index()
    {
        $courts = Court::latest()->get();
        return view('admin.courts.index', compact('courts'));
    }

    public function create()
    {
        return view('admin.courts.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name'           => 'required|string|max:255',
            'type'           => 'required|string',
            'price_per_hour' => 'required|numeric|min:0',
            'location'       => 'nullable|string',
            'description'    => 'nullable|string',
        ]);

        Court::create($request->all());
        return redirect()->route('admin.courts.index')->with('success', 'Cancha creada.');
    }

    public function show(Court $court)
    {
        $court->load('schedules', 'reservations');
        return view('admin.courts.show', compact('court'));
    }

    public function edit(Court $court)
    {
        return view('admin.courts.edit', compact('court'));
    }

    public function update(Request $request, Court $court)
    {
        $request->validate([
            'name'           => 'required|string|max:255',
            'type'           => 'required|string',
            'price_per_hour' => 'required|numeric|min:0',
        ]);

        $court->update($request->all());
        return redirect()->route('admin.courts.index')->with('success', 'Cancha actualizada.');
    }

    public function destroy(Court $court)
    {
        $court->update(['is_active' => false]);
        return redirect()->route('admin.courts.index')->with('success', 'Cancha desactivada.');
    }
}