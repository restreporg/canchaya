<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Reservation;
use Illuminate\Http\Request;

class ReservationController extends Controller
{
    // El admin ve TODAS las reservas
    public function index()
    {
        $reservations = Reservation::with(['user', 'court'])
            ->orderBy('start_datetime', 'desc')
            ->get();
        return view('admin.reservations.index', compact('reservations'));
    }

    public function show(Reservation $reservation)
    {
        $reservation->load('user', 'court', 'payment', 'review');
        return view('admin.reservations.show', compact('reservation'));
    }

    // El admin puede cambiar el estado manualmente
    public function update(Request $request, Reservation $reservation)
    {
        $request->validate([
            'status' => 'required|in:pendiente,confirmada,cancelada,completada',
        ]);

        $reservation->update(['status' => $request->status]);
        return redirect()->route('admin.reservations.show', $reservation)
                         ->with('success', 'Estado actualizado.');
    }

    public function destroy(Reservation $reservation)
    {
        $reservation->delete();
        return redirect()->route('admin.reservations.index')->with('success', 'Reserva eliminada.');
    }
}