<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Payment;
use Illuminate\Http\Request;

class PaymentController extends Controller
{
    // El admin ve todos los pagos
    public function index()
    {
        $payments = Payment::with(['user', 'reservation.court'])
            ->orderBy('created_at', 'desc')
            ->get();
        return view('admin.payments.index', compact('payments'));
    }

    public function show(Payment $payment)
    {
        $payment->load('user', 'reservation.court');
        return view('admin.payments.show', compact('payment'));
    }

    // El admin puede marcar un pago como reembolsado
    public function update(Request $request, Payment $payment)
    {
        $request->validate([
            'status' => 'required|in:pendiente,pagado,fallido,reembolsado',
        ]);

        $payment->update(['status' => $request->status]);
        return redirect()->route('admin.payments.show', $payment)
                         ->with('success', 'Pago actualizado.');
    }
}